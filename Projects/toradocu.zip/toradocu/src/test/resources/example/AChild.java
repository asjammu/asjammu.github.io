package example;

public class AChild extends AClass {

	/**
	 * @throws IllegalArgumentException if z is null
	 */
	@Override
	public double baz(Object z) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	/**
	 * @throws IllegalArgumentException if x is null
	 */
	public double vararg(Object... x) {
		// TODO Auto-generated method stub
		return 0;
	}
}
