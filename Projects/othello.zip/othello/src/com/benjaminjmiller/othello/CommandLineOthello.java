package com.benjaminjmiller.othello;

import java.util.Scanner;

public class CommandLineOthello {

    public static void runGame() {
        Game game = new Game();
        while (!game.isOver()) {
            System.out.println(game.currentPlayer() + "'s turn");
            paintBoard(game);
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter row");
            int row = scanner.nextInt();
            System.out.println("Enter column");
            int col = scanner.nextInt();
            if (!game.move(row - 1, col - 1)) {
                System.out.println("Invalid move");
            }
        }
        paintBoard(game);
        System.out.println("Game Over! " + game.winner() + " won!");
    }

    private static void paintBoard(Game game) {
        System.out.println("    1     2     3     4     5     6     7     8   ");
        for (int i = 0; i < 8; i++) {
            System.out.print(i + 1 + " ");
            for (int j = 0; j < 8; j++) {
                Piece.Color color = game.getPieceAt(i, j);
                if (color == null) {
                    System.out.print("EMPTY ");
                } else {
                    System.out.print(game.getPieceAt(i, j) + " ");
                }
            }
            System.out.println();
        }
    }

}
