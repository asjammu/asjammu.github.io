package com.benjaminjmiller.othello;

import java.util.ArrayList;
import java.util.List;

class Board {

    private int numWhite;
    private int numBlack;
    private static final int BOARD_SIZE = 8;
    private Piece[][] board;
    public Board() {
        numWhite = 0;
        numBlack = 0;
        board = new Piece[BOARD_SIZE][BOARD_SIZE];
        putStartPieces();
    }

    int numWhite() {
        return numWhite;
    }

    int numBlack() {
        return numBlack;
    }

    Piece getPieceAt(int row, int col) {
        return board[row][col];
    }

    private List<Piece> capturableEnemies(int row, int col, Piece.Color color) {
        Piece.Color otherColor = color == Piece.Color.WHITE ? Piece.Color.BLACK : Piece.Color.WHITE;
        List<Piece> result = new ArrayList<>();
        if (top(row, col) != null && top(row, col).getColor() == otherColor && isCapturable(otherColor, row - 1, col)) {
            result.add(top(row, col));
        }
        if (bottom(row, col) != null && bottom(row, col).getColor() == otherColor && isCapturable(otherColor, row + 1, col)) {
            result.add(bottom(row, col));
        }
        if (left(row, col) != null && left(row, col).getColor() == otherColor && isCapturable(otherColor, row, col - 1)) {
            result.add(left(row, col));
        }
        if (right(row, col) != null && right(row, col).getColor() == otherColor && isCapturable(otherColor, row, col + 1)) {
            result.add(right(row, col));
        }
        return result;
    }

    private boolean isCapturable(Piece.Color color, int row, int col) {
        Piece.Color otherColor = color == Piece.Color.WHITE ? Piece.Color.BLACK : Piece.Color.WHITE;
        Piece top = top(row, col);
        Piece bottom = bottom(row, col);
        Piece left = left(row, col);
        Piece right = right(row, col);
        if (top != null && bottom != null && otherColor == top.getColor() && top.getColor() == bottom.getColor()) {
            return true;
        }
        if (left != null && right != null && otherColor == left.getColor() && left.getColor() == right.getColor()) {
            return true;
        }
        return false;
    }

    private Piece top(int row, int col) {
        if (row == 0) {
            return null;
        }
        return board[row - 1][col];
    }

    private Piece bottom(int row, int col) {
        if (row == BOARD_SIZE - 1) {
            return null;
        }
        return board[row + 1][col];
    }

    private Piece left(int row, int col) {
        if (col == 0) {
            return null;
        }
        return board[row][col - 1];
    }

    private Piece right(int row, int col) {
        if (col == BOARD_SIZE - 1) {
            return null;
        }
        return board[row][col + 1];
    }

    boolean setPiece(int row, int col, Piece.Color color) {
        if (board[row][col] != null) {
            return false;
        }
        if (isCapturable(color, row, col)) {
            return false;
        }
        board[row][col] = new Piece(color, row, col);
        List<Piece> piecesToCapture = capturableEnemies(row, col, color);
        if (piecesToCapture.size() == 0) {
            board[row][col] = null;
            return false;
        }
        if (color == Piece.Color.WHITE) {
            numWhite++;
        } else {
            numBlack++;
        }
        while (!piecesToCapture.isEmpty()) {
            Piece p = piecesToCapture.remove(piecesToCapture.size() - 1);
            p.flip();
            if (color == Piece.Color.WHITE) {
                numWhite++;
                numBlack--;
            } else {
                numBlack++;
                numWhite--;
            }
            piecesToCapture.addAll(capturableEnemies(p.row(), p.col(), color));
        }
        return true;
    }

    boolean noMovesLeft(Piece.Color color) {
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (board[i][j] == null) {
                    board[i][j] = new Piece(color, i, j);
                    boolean works = !isCapturable(color, i, j) && capturableEnemies(i, j, color).size() > 0;
                    board[i][j] = null;
                    if (works) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    void clearBoard() {
        numWhite = 0;
        numBlack = 0;
        board = new Piece[BOARD_SIZE][BOARD_SIZE];
        putStartPieces();
    }

    private void putStartPieces() {
        board[3][3] = new Piece(Piece.Color.BLACK, 3, 3);
        board[3][4] = new Piece(Piece.Color.WHITE, 3, 4);
        board[4][3] = new Piece(Piece.Color.WHITE, 4, 3);
        board[4][4] = new Piece(Piece.Color.BLACK, 4, 4);
    }
}
