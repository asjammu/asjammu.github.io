package com.benjaminjmiller.othello;

class Player {

    Piece.Color side;
    private int pieces;
    public Player(Piece.Color color) {
        pieces = 30;
        side = color;
    }

    int pieces() {
        return pieces;
    }

    void usePiece() {
        pieces--;
    }
}
