package com.benjaminjmiller.othello;

public class Piece {

    public enum Color { BLACK, WHITE };
    private Color color;
    private int row;
    private int col;

    Piece(Color color, int row, int col) {
        this.color = color;
        this.row = row;
        this.col = col;
    }

    Color getColor() {
        return color;
    }

    void flip() {
        if (color == Color.BLACK) {
            color = Color.WHITE;
        } else {
            color = Color.BLACK;
        }
    }

    int row() {
        return row;
    }

    int col() {
        return col;
    }

}
