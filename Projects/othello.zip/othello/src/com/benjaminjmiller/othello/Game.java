package com.benjaminjmiller.othello;

import java.util.Scanner;

public class Game {

    private Player currentPlayer;
    private Board board;
    private boolean noMovesLeft;
    private Player winner;
    private Player player1;
    private Player player2;

    public Game() {
        player1 = new Player(Piece.Color.WHITE);
        player2 = new Player(Piece.Color.BLACK);
        currentPlayer = player1;
        board = new Board();
        noMovesLeft = false;
        winner = null;
    }

    public boolean move(int row, int col) {
        if (noMovesLeft) {
            return false;
        }
        if (!board.setPiece(row, col, currentPlayer.side)) {
            return false;
        }
        currentPlayer.usePiece();
        currentPlayer = player1 == currentPlayer ? player2 : player1;
        if (board.noMovesLeft(currentPlayer.side)) {
            noMovesLeft = true;
            winner = determineWinner();
        }
        return true;
    }

    private Player determineWinner() {
        int white = player1.pieces() + board.numWhite();
        int black = player2.pieces() + board.numBlack();
        if (white == black) {
            return null;
        }
        return white > black ? player1 : player2;
    }

    public Piece.Color winner() {
        if (winner == null) {
            return null;
        }
        return winner.side;
    }

    public boolean isOver() {
        return noMovesLeft;
    }

    public Piece.Color currentPlayer() {
        return currentPlayer.side;
    }

    public void reset() {
        board.clearBoard();
        currentPlayer = player1;
        noMovesLeft = false;
        winner = null;
        player1 = new Player(Piece.Color.WHITE);
        player2 = new Player(Piece.Color.BLACK);
    }

    public Piece.Color getPieceAt(int row, int col) {
        Piece p = board.getPieceAt(row, col);
        if (p == null) {
            return null;
        }
        return p.getColor();
    }

}
