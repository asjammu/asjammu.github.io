/* Simplethreads Instructional Thread Package
 *
 * sthread_user.c - Implements the sthread API using user-level threads.
 *
 *    You need to implement the routines in this file.
 *
 * Change Log:
 * 2002-04-15        rick
 *   - Initial version.
 */

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

#include <sthread.h>
#include <sthread_queue.h>
#include <sthread_user.h>
#include <sthread_ctx.h>
#include <sthread_preempt.h>

struct _sthread {
  sthread_ctx_t *saved_ctx;
  /* Add your fields to the thread data structure here */
  int status; //0=running, 1=blocked (waiting to be joined), 2=ready, 3=finished
  int joinable; //0=no, 1=yes
  struct _sthread *waiting_thread; // a thread that is waiting on this one, for joinable threads
  int joined; //0=no, 1=yes
  //can potentially combine joinable and joined by setting joinable to 0 once a thread has been joined
  //but I don't really want to mess with that till later
  void* return_value; //for threads that have finished
  //start function and args for initialization
  sthread_start_func_t sr;
  void* ar;
};

//global variables!
sthread_queue_t queue;
sthread_queue_t finished_queue;
sthread_t current_thread;

/*********************************************************************/
/* Part 1: Creating and Scheduling Threads                           */
/*********************************************************************/

void sthread_user_scheduler(void);

void sthread_user_init(void) {
  //create the thread queue
  queue = sthread_new_queue();
  finished_queue = sthread_new_queue();

  //initialize the tcb
  //it's full of default values because it'll get overwritten when another thread runs
  sthread_t sth = (sthread_t)malloc(sizeof(struct _sthread));
  sth->saved_ctx = sthread_new_blank_ctx();
  sth->status = 0;
  sth->joinable = 0;
  sth->waiting_thread = NULL;
  sth->joined = 0;
  sth->return_value = NULL;
  current_thread = sth;
  sthread_preemption_init(&sthread_user_scheduler, 20);
}

/*
  (from "Hints")
  The start routine passed to sthread_new_ctx does not take any arguments
  (unlike the routine that your sthread_user_create is passed).
  So you can't create a new stack directly with the user-supplied routine;
  you need to supply a routine that takes no arguments but somehow winds
  up invoking the user's routine with the user's argument.
 */
void sthread_catch_function(void) {
  //I want to make a function that calls start_routine, passing arg
  //then after it calls start_routine, it calls sthread_user_exit
  //passing the return value from start_routine
  //there's probably a better way to do it, but I can't figure it out
  //so I'm using global variables!

  //this function is basically the "base" for a thread
  //whenever a thread's starting function returns, it returns to here
  splx(LOW);
  void* ret = (*current_thread->sr)(current_thread->ar);
  sthread_user_exit(ret);
}

sthread_t sthread_user_create(sthread_start_func_t start_routine, void *arg,
                              int joinable) {
  //initialize a tcb
  sthread_t sth = (sthread_t)malloc(sizeof(struct _sthread));
  sth->sr = start_routine;
  sth->ar = arg;
  sth->saved_ctx = sthread_new_ctx(&sthread_catch_function);
  sth->status = 2;
  sth->joinable = joinable;
  sth->waiting_thread = NULL;
  sth->joined = 0;
  sth->return_value = NULL;

  //put this thread in the thread queue
  splx(HIGH);
  sthread_enqueue(queue, sth);
  splx(LOW);
  return sth;
}

void sthread_user_exit(void *ret) {
  //marks current thread as finished
  //NEVER run finished threads
  splx(HIGH);
  current_thread->status = 3;
  current_thread->return_value = ret;
  if (current_thread->joinable && current_thread->waiting_thread) {
    // Unblock the thread waiting to join this thread.
    current_thread->waiting_thread->status = 2;
  }
  sthread_user_yield();
}

void* sthread_user_join(sthread_t t) {
  //set own state as blocked and spin until t is finished
  //then get return value from t
  //note that this will only be called once, so it yields until t is finished
  splx(HIGH);
  if (t->status != 3) {
    // The thread to join has not yet terminated so block this thread and
    // wait until unblocked by t.
    current_thread->status = 1;
    t->waiting_thread = current_thread;
    sthread_user_yield();
  }
  splx(LOW);
  t->joined = 1;
  void *retval = t->return_value;
  sthread_free_ctx(t->saved_ctx);
  return retval;
}

//scheduler: when a currently running thread exits/yields,
//go to a different thread
//also if the thread you just got is finished, garbage collect it
//then later you can just call the scheduler on the timer

void sthread_user_scheduler(void) {
  splx(HIGH);
  // First garbage collect finished threads.
  sthread_t finished_thread;
  while (finished_thread = sthread_dequeue(finished_queue)) {
    sthread_free_ctx(finished_thread->saved_ctx);
  }
  // Update running thread to ready.
  if (current_thread->status == 0) {
    current_thread->status = 2;
  }
  if (current_thread->status == 3 && !current_thread->joinable) {
    // Schedule the current thread for garbage collection next time.
    sthread_enqueue(finished_queue, current_thread);
  } else if (current_thread->status != 3) {
    // Schedule the current thread for some later time.
    sthread_enqueue(queue, current_thread);
  }
  // Find the next ready thread to switch to.
  if (sthread_queue_is_empty(queue)) {
    // No threads available to run in queue.
    // All threads, including the current thread, have finished.
    sthread_free_ctx(current_thread->saved_ctx);
    sthread_free_queue(queue);
    sthread_dequeue(finished_queue);
    sthread_free_queue(finished_queue);
    sthread_queue_clear_free_list();
    exit(0);
  }
  sthread_t next_thread;
  while ((next_thread = sthread_dequeue(queue)) && next_thread->status != 2) {
    // This thread is blocked so find another one.
    sthread_enqueue(queue, next_thread);
  }

  //so now you have a ready thread!
  //switch contexts...
  sthread_t old_thread = current_thread;
  current_thread = next_thread;
  sthread_switch(old_thread->saved_ctx, current_thread->saved_ctx);
  //so... a thread would only ever come "out" of a context switch HERE
  //or in the function that it's being started as (if it's a new thread) I guess
  //anyway, if it's still here:
  current_thread->status = 0;
  splx(LOW);
}

void sthread_user_yield(void) {
  //tell scheduler
  sthread_user_scheduler();
}





/*********************************************************************/
/* Part 2: Synchronization Primitives                                */
/*********************************************************************/

struct _sthread_mutex {
  /* Fill in mutex data structure */
  lock_t lock;
  sthread_queue_t queue;
};

sthread_mutex_t sthread_user_mutex_init() {
  sthread_mutex_t lock = (sthread_mutex_t)malloc(sizeof(struct _sthread_mutex));
  lock->lock = 0;
  lock->queue = sthread_new_queue();
  return lock;
}

void sthread_user_mutex_free(sthread_mutex_t lock) {
  sthread_free_queue(lock->queue);
  free(lock);
}

void sthread_user_mutex_lock(sthread_mutex_t lock) {
  while (atomic_test_and_set(&lock->lock)) {
    splx(HIGH);
    sthread_enqueue(lock->queue, current_thread);
    current_thread->status = 1;
    sthread_user_yield();
  }
}

void sthread_user_mutex_unlock(sthread_mutex_t lock) {
  atomic_clear(&lock->lock);
  splx(HIGH);
  sthread_t thread = sthread_dequeue(lock->queue);
  splx(LOW);
  if (thread) {
    thread->status = 2;
  }
}


struct _sthread_cond {
  /* Fill in condition variable structure */
  sthread_queue_t queue;
};

sthread_cond_t sthread_user_cond_init(void) {
  sthread_cond_t cond = (sthread_cond_t)malloc(sizeof(struct _sthread_cond));
  cond->queue = sthread_new_queue();
  return cond;
}

void sthread_user_cond_free(sthread_cond_t cond) {
  sthread_free_queue(cond->queue);
  free(cond);
}

void sthread_user_cond_signal(sthread_cond_t cond) {
  splx(HIGH);
  sthread_t thread = sthread_dequeue(cond->queue);
  splx(LOW);
  if (thread) {
    thread->status = 2;
  }
}

void sthread_user_cond_broadcast(sthread_cond_t cond) {
  // Ready all threads in wait queue.
  sthread_t thread;
  splx(HIGH);
  while (thread = sthread_dequeue(cond->queue)) {
    thread->status = 2;
  }
  splx(LOW);
}

void sthread_user_cond_wait(sthread_cond_t cond,
                            sthread_mutex_t lock) {
  splx(HIGH);
  sthread_user_mutex_unlock(lock);
  current_thread->status = 1;
  sthread_enqueue(cond->queue, current_thread);
  sthread_user_yield();
  sthread_user_mutex_lock(lock);
}
