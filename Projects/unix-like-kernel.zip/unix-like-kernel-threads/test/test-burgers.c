// Test burgers
// /test-burgers #producers #consumers #items debug
// CSE 451 17sp

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sthread.h>



#define STACK_CAPACITY 1000


typedef struct stack_data {
  int size;
  int * values;
  int capacity;
} * stack;

static int consumed_burgers;
static int created_burgers;
static int total_burgers;
static sthread_mutex_t mutex;
static sthread_cond_t can_eat;
static sthread_cond_t can_make;
static stack burgers;
static int DEBUG;

// Start point for each threads
// Argument is an int pointer 
// to the corresponding thread ID
int student_start(void *arg);
int cook_start(void *arg);

int main(int argc, char **argv) {
  if(DEBUG) printf("Testing everything*, impl: %s\n",
         (sthread_get_impl() == STHREAD_PTHREAD_IMPL) ? "pthread" : "user");
  if(argc != 5) {
    printf("Arguments Error. ./test-burgers num_cooks num_students num_threads debug\n");
    return EXIT_FAILURE;
  }

  // Parse Arguments  
  int num_cooks, num_students;
  num_cooks = atoi(argv[1]); 
  num_students = atoi(argv[2]); 
  total_burgers =  atoi(argv[3]);
  DEBUG =  atoi(argv[4]);

  // Initialize Threads and Stack
  sthread_t cooks[num_cooks];
  sthread_t students[num_students];
  burgers = (stack) malloc(sizeof(struct stack_data));
  if(burgers == NULL) {
    printf("Malloc Failure\n");
    return EXIT_FAILURE;
  }

  // Set stack fields and counter
  burgers->values = (int *) malloc(sizeof(int) * STACK_CAPACITY);
  if(burgers->values == NULL) {
    printf("Malloc Failure\n");
    free(burgers);
    return EXIT_FAILURE;
  }
  burgers->size = 0;
  burgers->capacity = STACK_CAPACITY;
  consumed_burgers = 0;
  if(DEBUG) printf("Consumed: %d Total: %d\n", consumed_burgers, total_burgers);

  
  // Initialize synchronization tools
  sthread_init();
  mutex = sthread_mutex_init();
  can_eat = sthread_cond_init();
  can_make = sthread_cond_init();
  if(DEBUG) printf("Thread/Mutex/CV initialization successful\n");


  // Spawn threads for consumers
  int *student_ids = (int *) malloc(num_students * sizeof(int));
  if(student_ids == NULL) {
    printf("Malloc Failure\n");
    free(burgers->values);
    free(burgers);
    return EXIT_FAILURE;
  }

  int i;

  for (i = 0; i < num_students; i++) {
    student_ids[i] = i;
    students[i] = sthread_create(student_start, &student_ids[i], 1);
    if(DEBUG) printf("Created %d Student\n", i);
    if (students[i] == NULL) {
      printf("sthread_create %d failed\n", i);
      return EXIT_FAILURE;
    }
  }
  if(DEBUG) printf("Students created successfully\n");

  // Spawn threads for producers
  int *cook_ids = (int *) malloc(num_cooks * sizeof(int));
  if(cook_ids == NULL) {
    printf("Malloc Failure\n");
    free(burgers->values);
    free(burgers);
    free(student_ids);
    return EXIT_FAILURE;
  }
  for (i = 0; i < num_cooks; i++) {
    cook_ids[i] = i;
    cooks[i] = sthread_create(cook_start, &cook_ids[i], 1);
    if(DEBUG) printf("Created %d Cook\n", i);
    if (cooks[i] == NULL) {
      printf("sthread_create %d failed\n", i);
      return EXIT_FAILURE;
    }
  }
  if(DEBUG) printf("Cooks created successfully\n");


  // Track the amount of burgers each thread consumed/produced
  int student_counts[num_students];
  int cook_counts[num_cooks];  

  // Let everything run
  for (i = 0; i < num_students; i++) {
    student_counts[i] = sthread_join(students[i]);
  }
  for (i = 0; i < num_cooks; i++) {
    cook_counts[i] = sthread_join(cooks[i]);
  }

  if(DEBUG) printf("Everything has been joined\n");


  // Debug Code: How many each thread consumed/produced
  if(DEBUG) {
    for (i = 0; i < num_students; i++) {
      printf("Student %d ate %d burgers\n", i, student_counts[i]);
    }
    for (i = 0; i < num_cooks; i++) {
      printf("Cook %d made %d burgers\n", i, cook_counts[i]);
    }
  }
 

  // free everything
  sthread_cond_free(can_eat);
  sthread_cond_free(can_make);
  sthread_mutex_free(mutex);
  free(burgers->values);
  free(burgers);
  free(student_ids);
  free(cook_ids);
  for (i = 0; i < num_students; i++)
    free(students[i]);
  for (i = 0; i < num_cooks; i++)
    free(cooks[i]);

  if(DEBUG) printf("Everything Free'd correctly\n");
  return EXIT_SUCCESS;
}

/* Consumer thread - remove items from the "buffer"
 * you have consumed the . 
 * Arg is a pointer to the id of the thread*/
int student_start(void *arg) {
  int eaten = 0;
  while (1) {

    // Grab lock
    // while we still need to eat more and there
    // are no burgers in the stack, wait for the lock
    sthread_mutex_lock(mutex);    
    while (consumed_burgers < total_burgers && burgers->size == 0) {
      sthread_cond_wait(can_eat, mutex);
    }

    // Have lock at this point

    // If we've consumed the amount we want,
    // Unlock mutex and break - we're done
    // wake up all other consumers
    if(consumed_burgers == total_burgers) {
      sthread_mutex_unlock(mutex);
      sthread_cond_broadcast(can_eat);
      break;
    }

    // Eat a burger
    // Remove burger from stack
    // Increment consumed burger count
    // signal to producers
    // release lock
    eaten++;
    int index = burgers->size - 1;
    int burger = burgers->values[index];
    burgers->size--;
    consumed_burgers++;
    if(DEBUG) printf("Student %d ate burger: %d\n", *((int*)arg), burger);
    sthread_mutex_unlock(mutex);
    sthread_cond_signal(can_make);

  }
  if(DEBUG) printf("Consumer %d Finished\n", *((int*)arg));
  return eaten;
}
/* Producer thread - remove items from the "buffer"
 * until they've all been transfered. 
 * Arg is a pointer to the id of the thread*/
int cook_start(void *arg) {
  int made = 0;
  while (1) {

    // Grab lock
    // while burgers still need to be made and
    // the stack capacity is full, wait
    sthread_mutex_lock(mutex);
    while(consumed_burgers < total_burgers && burgers->size == burgers->capacity) {
      sthread_cond_wait(can_make, mutex);
    }

    // Have lock

    // We done fam
    // wake up all the waiting producers
    if(created_burgers == total_burgers) {
      sthread_mutex_unlock(mutex);
      sthread_cond_broadcast(can_make);
      break;
    }


    // Add burger, unlock, signal
    made++;
    burgers->values[burgers->size] = ++created_burgers;
    burgers->size++;
    if(DEBUG) printf("Cook %d produced burger: %d\n", *((int*)arg), created_burgers);
    sthread_mutex_unlock(mutex);
    sthread_cond_signal(can_eat);
  }
  if(DEBUG) printf("Producer %d Finished\n", *((int*)arg));
  return made;
}
