# Pet Adoption App

## Screenshots
![Android Login](/screenshots/login_screen.png)  ![Android Swipe Dogs](/screenshots/swipe_dogs_screen.png)  ![Android Liked Dogs](/screenshots/liked_dogs_screen.png)
![Android Dog Profile](/screenshots/dog_profile_screen.png)
